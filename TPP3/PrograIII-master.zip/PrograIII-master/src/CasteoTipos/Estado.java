package CasteoTipos;

import java.util.ArrayList;

public class Estado {
	private ArrayList<Character> estadoOps;
	private ArrayList<Double> estadoNums;
	public Estado() {
		this.estadoOps=new ArrayList<Character>();
		this.estadoNums= new ArrayList<Double>();
	}
	
	public void SetEstado(Intermediario o) {
		this.estadoOps = o.getOperandosArray();
		this.estadoNums= o.getNumerosArray();
	}
	public ArrayList<Double> getEstadoNums() {
		return this.estadoNums;
		
	}
	public ArrayList<Character> getEstadoOps() {
		return this.estadoOps;
		
	}
	public void SetEstado(ArrayList<Character> c, ArrayList<Double> d) {
		this.estadoOps.addAll(c);
		this.estadoNums.addAll(d);
	}
	
}
