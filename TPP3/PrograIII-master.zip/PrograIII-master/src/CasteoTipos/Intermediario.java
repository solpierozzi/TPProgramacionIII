package CasteoTipos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import repo.ArchivoOps;

public class Intermediario {
	private ArrayList<Character> operandos;
	private ArrayList<Double> numeros;
	private String numeroActual;

	public Intermediario() {
		numeroActual="";
		operandos = new ArrayList<Character>();
		numeros = new ArrayList<Double>();
		
	}
	public void agregar(char c,int ind_ult_op,int ind_actual){
		if(esOperando(c)){
			if(ind_actual==0)
				operandos.add(c);
			else if(ind_actual-ind_ult_op!=1 || ind_actual-ind_ult_op==1 && !numeroActual.equals("")){
				operandos.add(c);
				try{
					numeros.add(Double.parseDouble(numeroActual));
					numeroActual="";
				}
				catch(NumberFormatException e){
				}
			}
			else{
				numeroActual=""+c;
			}
		}
		else{
			numeroActual+=c;
		}
	}
	public void eliminar(char c){
		if(esOperando(c) && operandos.size()>0){
			operandos.remove(operandos.size()-1);
		}
		else{
			numeroActual=numeroActual.substring(0,numeroActual.length()-1);
		}
	}

	public void agregarUltimo(){
			numeros.add(Double.parseDouble(numeroActual));
			numeroActual="";
	}
	public void agregar(String s){
		numeros.add(Double.parseDouble(s));
	}
	public void reiniciarValores() {
		numeros.clear();
		operandos.clear();
	}

	public List<Character> getOperandos() {
		return operandos;
	}
	public ArrayList<Character> getOperandosArray() {
		return operandos;
	}

	public List<Double> getNumeros() {
		return numeros;
	}
	public ArrayList<Double> getNumerosArray() {
		return numeros;
	}

	private boolean esOperando(char s) {
		return s=='x' || s=='/' || s=='+' || s=='-';
	}
	private Intermediario getEstado()  {
		Intermediario temp = new Intermediario();
		temp.operandos.addAll(this.operandos);
		temp.numeros.addAll(this.numeros);

	
		
	
		
		/*try {
			Object a = this.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return temp;
		
	}
	public void setEstado(Estado e) {
		e.SetEstado(getEstado());
		
	}
	private void setOperandos(ArrayList<Character> c) {
		this.operandos=c;
		
	}
	private void setNumeros(ArrayList<Double> d) {
		this.numeros = d;
	}
	
	public void volverAEstadoAnt(Estado estado) {
		this.operandos=estado.getEstadoOps();
		this.numeros= estado.getEstadoNums();
	}
	public void getMemoria(Estado estado) {
		System.out.println(estado.getEstadoNums());
		System.out.println(estado.getEstadoOps());
	}
	/*public ArrayList<Character> getEstadoOps(){
	return	estado.getEstadoOps();
	}
	public ArrayList<Double> getEstadoNums(){
		return estado.getEstadoNums();
	}*/
	

}
