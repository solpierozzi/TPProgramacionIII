package CasteoTipos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import repo.ArchivoOps;

public class CareTaker {
	private LinkedList<Object> estAGuardar;
	private ArchivoOps repo;
	
	
	public CareTaker() {
	estAGuardar= new LinkedList<Object>();
	this.repo=new ArchivoOps();
	}
	
	 
	
	
	private void guardarEstados() throws IOException {
		repo.agregarAMemoria(estAGuardar, "Calcu.json");
	}
	public void setMemoria(List<Double> list, List<Character> list2) throws IOException {
		estAGuardar.add(list);
		estAGuardar.add(list2);
		guardarEstados();
	}
	public ArrayList<Double> getNumerosDMemoria(int estado) {
		return repo.getNumsDMemo();
	}
	public ArrayList<Character> getEstadoOperandos() {
		return repo.getOperandos();
	}
	
}
