package gui;
import java.awt.BorderLayout;
import javax.swing.JFrame;

import java.awt.Toolkit;

@SuppressWarnings("serial")
public class Window extends JFrame {
	private Pantalla pantalla=new Pantalla();
	public Window() {
		setVisible(true);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Window.class.getResource("/Imagenes/IconoCalculadora.png")));
		setTitle("Calc");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 357, 412);
		inicializar();
	}

	private void inicializar() {
	    add(pantalla, BorderLayout.CENTER);   
	}

}