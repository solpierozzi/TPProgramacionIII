package gui;
public class Principal {
	public static void main(String[] args) {
		Window ventana=new Window();
		ventana.setVisible(true);
	}
}
