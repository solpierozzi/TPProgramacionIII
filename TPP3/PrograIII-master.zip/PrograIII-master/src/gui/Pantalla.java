package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JPanel;

import CasteoTipos.CareTaker;
import CasteoTipos.Estado;
import CasteoTipos.Intermediario;
import logic.Calculadora;

import javax.swing.JTextField;

import java.awt.Color;
import java.awt.Font;

import javax.swing.SwingConstants;

public class Pantalla extends JPanel implements ActionListener {
	private  JButton[] botones ;
	private JTextField resultados = new JTextField();
	private int indice_operando = 0;
	private int indice_decimal = 0;
	private String operacionCopiada;
	private boolean igual = false;
	private Intermediario intermediario;
	private Calculadora calculadora;
	private JTextField calculoAnterior;
	private CareTaker interRepo;
	private Estado estado;
	private Boolean memoriaOn;

	public Pantalla() {
		botones=new JButton[20];
		calculadora = new Calculadora();
		intermediario = new Intermediario();
		interRepo = new CareTaker();
		estado= new Estado();
		memoriaOn=true;
		setBorder(null);
		setLayout(null);
		agregarBotones();
		agregarPantallaResultados();
		agregarVisionDeCalculoAnterior();
		

	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		int largoAnterior=resultados.getText().length();
		if (!e.getSource().equals(botones[11])) {
			igual = false;
			reaccionarSegunEvento(e);
			
			int largoActual=resultados.getText().length();
			String textoPantalla=resultados.getText();
			
			if(largoActual>largoAnterior){
				intermediario.agregar(textoPantalla.charAt(largoActual-1),indice_operando,largoActual-1);
				if(!esNumero(textoPantalla.charAt(largoActual-1))){
					if(textoPantalla.charAt(largoActual-1)!='.')
						indice_operando=largoActual-1;
					else
						indice_decimal=largoActual-1;
				}
			}
		} else {
			if (igual) {
				resetValores();
			} else {
				try {
					
					calcularResultado();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			igual = true;
		}
		
		}

	private void reaccionarSegunEvento(ActionEvent e) {
		agregarSiEsNumero(e);
		agregarSiEsOperandoYSePuedeUbicar(e);
		borrarSiSeSolicita(e);
		copiarSiSeSolicita(e);
		pegarSiSeSolicita(e);
	}
	
	private void pegarSiSeSolicita(ActionEvent e) {
		if (e.getSource().equals(botones[19])) 
			if(sePuedePegar(resultados.getText()))
				resultados.setText(resultados.getText()+operacionCopiada);
	}

	private void copiarSiSeSolicita(ActionEvent e) {
		if (e.getSource().equals(botones[18]))
			if(sePuedeCopiar(resultados.getText()))
				operacionCopiada = resultados.getText();

	}

	private void calcularResultado() throws IOException {
		if (indice_operando != resultados.getText().length()-1 && indice_decimal != resultados.getText().length()-1) {
			calculoAnterior.setText(resultados.getText());
			intermediario.agregarUltimo();
			if(memoriaOn) {
			setMemoria();
			}
			try {
				resultados.setText(calculadora.operar(intermediario.getOperandos(),intermediario.getNumeros()).toString());
				intermediario.reiniciarValores();
				intermediario.agregar(resultados.getText());
				arreglarAuxiliares();
			} catch (Exception e) {
				resultados.setText("SyntaxError");
			}
		} 
		else{
			resultados.setText("SyntaxError");
		}
		
		intermediario.getMemoria(estado);
	}

	private void agregarSiEsNumero(ActionEvent e) {
		if (e.getSource().equals(botones[10]))
			resultados.setText(resultados.getText() + "1");
		 if (e.getSource().equals(botones[6]))
			resultados.setText(resultados.getText() + "2");
		 if (e.getSource().equals(botones[2]))
			resultados.setText(resultados.getText() + "3");
		 if (e.getSource().equals(botones[9]))
			resultados.setText(resultados.getText() + "4");
		 if (e.getSource().equals(botones[5]))
			resultados.setText(resultados.getText() + "5");
		 if (e.getSource().equals(botones[1]))
			resultados.setText(resultados.getText() + "6");
		 if (e.getSource().equals(botones[8]))
			resultados.setText(resultados.getText() + "7");
		 if (e.getSource().equals(botones[4]))
			resultados.setText(resultados.getText() + "8");
		 if (e.getSource().equals(botones[0]))
			resultados.setText(resultados.getText() + "9");		
		 if (e.getSource().equals(botones[3]))
			resultados.setText(resultados.getText() + "0");	
		}

	private void agregarSiEsOperandoYSePuedeUbicar(ActionEvent e) {
		boolean hayCaracter=!resultados.getText().isEmpty();
		if (e.getSource().equals(botones[12])) {
			if (hayCaracter && esNumero(resultados.getText().charAt(resultados.getText().length() - 1))) 
				resultados.setText(resultados.getText() + "+");
		}
		if (e.getSource().equals(botones[13])) {
			if (puedeUbicarMenos()) 
				resultados.setText(resultados.getText() + "-");
		}
		if (e.getSource().equals(botones[14])) {
			if (hayCaracter && esNumero(resultados.getText().charAt(resultados.getText().length() - 1))) 
				resultados.setText(resultados.getText() + "x");
		}
		if (e.getSource().equals(botones[15])) {
			if (hayCaracter && esNumero(resultados.getText().charAt(resultados.getText().length() - 1))) 
				resultados.setText(resultados.getText() + "/");
		}
		if (e.getSource().equals(botones[7])) 
			if (puedeUbicarDecimal()) {
				resultados.setText(resultados.getText() + ".");
		}
	}

	private void borrarSiSeSolicita(ActionEvent e) {
		if (e.getSource().equals(botones[16])&& resultados.getText().length() > 0) {
			intermediario.eliminar(resultados.getText().charAt(resultados.getText().length()-1));
			resultados.setText(resultados.getText().substring(0,resultados.getText().length() - 1));
			arreglarAuxiliares();
		}
		if (e.getSource().equals(botones[17])) {
			resetValores();
			resultados.setText("");
			calculoAnterior.setText("");
		}
	}
	
	private boolean puedeUbicarMenos() {
		boolean ret = false;
		String textoPantalla = resultados.getText();
		if (textoPantalla.isEmpty())
			ret = true;
		else {
			if (textoPantalla.length() == 1)
				ret = textoPantalla.charAt(0) == '-'|| esNumero(textoPantalla.charAt(textoPantalla.length()-1));
			else {
				ret = textoPantalla.endsWith("-")|| textoPantalla.endsWith("x")|| textoPantalla.endsWith("/");
				ret = ret && esNumero(textoPantalla.charAt(textoPantalla.length()-2))
						|| esNumero(textoPantalla.charAt(textoPantalla.length()-1));
			}
		}
		return ret;
	}
	private void arreglarAuxiliares(){
		indice_decimal=0;
		indice_operando=0;
		for(int i=0;i<resultados.getText().length();i++){
			if(resultados.getText().charAt(i)=='.')
				indice_decimal=i;
			else{
				if(!esNumero(resultados.getText().charAt(i)))
					indice_operando=i;
			}
		}
	}
	private boolean puedeUbicarDecimal() {
		String textoPantalla = resultados.getText();
		int i = indice_operando;
		boolean ret = !textoPantalla.isEmpty() && textoPantalla.length()-i!=1 || i==0;
		i++;
		while (i < textoPantalla.length()) {
			ret = ret && esNumero(textoPantalla.charAt(i));
			i++;
		}
		return ret;
	}

	private boolean esNumero(char c) {
		try {
			Integer.parseInt(Character.toString(c));
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	private void agregarVisionDeCalculoAnterior() {
		calculoAnterior = new JTextField();
		calculoAnterior.setHorizontalAlignment(SwingConstants.RIGHT);
		calculoAnterior.setEditable(false);
		calculoAnterior.setBorder(null);
		calculoAnterior.setBackground(Color.WHITE);
		calculoAnterior.setBounds(10, 11, 282, 29);
		add(calculoAnterior);
	}

	private void agregarPantallaResultados() {
		resultados.setHorizontalAlignment(SwingConstants.RIGHT);
		resultados.setFont(new Font("Tahoma", Font.BOLD, 16));
		resultados.setBorder(null);
		resultados.setBackground(Color.WHITE);
		resultados.setEditable(false);
		resultados.setBounds(10, 38, 282, 50);
		add(resultados);
	}

	private void agregarBotones() {
		  String[] nombres={"9","6","3","0","8","5","2",".","7","4","1","=","+","-","x","/","c","ce","cy","pe"};
			int x=10;
			int y=99;
			  for(int i=0;i<botones.length;i++){
					botones[i]=new JButton(nombres[i]);
					botones[i].addActionListener(this);
					add(botones[i]);
					if(i>3 && i<8)
						x=68;
					if(i>=8 && i<12)
						x=126;
					if(i>=12 && i<16)
						x=186;
					if(i>=16)
						x=246;
					if(i==4 || i==8 || i==12 || i==16 || i==0)
						y=99;
					else
						y+=61;
					botones[i].setBounds(x, y, 50, 50);
				}
	}

	private void resetValores() {
		resultados.setText("");
		calculoAnterior.setText("");
		intermediario.reiniciarValores();
	}
	public void setMemoria() throws IOException {
		intermediario.setEstado(estado);
		interRepo.setMemoria(estado.getEstadoNums(), estado.getEstadoOps());
	}
	public void volverAEstadoAnt() {
		intermediario.volverAEstadoAnt(estado);
	}
	public boolean sePuedeCopiar(String s) {
		for(int i = 0; i<s.length(); i++) {
			if(!esNumero(s.charAt(i)) && s.charAt(i) != '.')
				return false;
		}
		return true;
	}
	public boolean sePuedePegar(String s) {
		int puntos = 0;
		int operandos = 0;
		for(int i = 0; i<s.length();i++) {
			if (!esNumero(s.charAt(i))) {
				if(s.charAt(i) == '.')
					puntos++;
				else {
					operandos++;
				}
			}
		}
		if(operandos == puntos)
			return true;
		return false;
	}
}
