package CalculadoraTest;

import static org.junit.Assert.*;

import logic.Calculadora;

import org.junit.Before;
import org.junit.Test;

public class DivisionTest {
	Calculadora calculadora;
	SeparadorDeNumeros separador;
	@Before public void inicializar(){
		calculadora=new Calculadora();
		separador=new SeparadorDeNumeros();
	}
	
	@Test
	public void divisionEnteraTest() {
		separador.agregar("10.0/5.0");
		assertEquals(Double.valueOf(10.0/5.0),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}

	@Test
	public void divisionDecimalTest() {
		separador.agregar("10.5/3.5");
		assertEquals(Double.valueOf(10.5/3.5),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void divisionPositivoNegativo() {
		separador.agregar("10.5/-3.5");
		assertEquals(Double.valueOf(10.5/-3.5),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void divisionNegativoPositivo() {
		separador.agregar("-10.5/3.5");
		assertEquals(Double.valueOf(-10.5/3.5),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void divisionNegativoNegativo() {
		separador.agregar("-10.5/-3.5");
		assertEquals(Double.valueOf(-10.5/-3.5),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test (expected=java.lang.ArithmeticException.class)
	public void denominadorCero() {
		separador.agregar("3.0/0.0");
		calculadora.operar(separador.getOperandos(),separador.getNumeros());
	}
	
	@Test (expected=java.lang.IllegalArgumentException.class)
	public void numeradorCero() {
		separador.agregar("0.0/3.0");
		calculadora.operar(separador.getOperandos(),separador.getNumeros());
	}
	
	

}
