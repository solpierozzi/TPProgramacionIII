package CalculadoraTest;

import static org.junit.Assert.*;


import logic.Calculadora;

import org.junit.Before;
import org.junit.Test;

public class MultiplicacionTest {
	Calculadora calculadora;
	SeparadorDeNumeros separador;
	@Before public void inicializar(){
		calculadora=new Calculadora();
		separador=new SeparadorDeNumeros();
	}
	@Test
	public void multiplicacionPositivoPositivo() {
		separador.agregar("2.0x4.0");
		assertEquals(Double.valueOf(2.0*4.0),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	@Test
	public void multiplicacionPositivoNegativo() {
		separador.agregar("2.0x-4.0");
		assertEquals(Double.valueOf(2.0*-4.0),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	@Test
	public void multiplicacionNegativoPositivo() {
		separador.agregar("-2.0x4.0");
		assertEquals(Double.valueOf(-2.0*4.0),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}

	@Test
	public void multiplicacionNegativoNegativo() {
		separador.agregar("-2.0x-4.0");
		assertEquals(Double.valueOf(-2.0*-4.0),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void multiplicacionPositivoPositivo_Decimal() {
		separador.agregar("5.0x4.9");
		assertEquals(Double.valueOf(5.0*4.9),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}

	@Test
	public void multiplicacionPositivoNegativo_Decimal() {
		separador.agregar("5.0x-4.9");
		assertEquals(Double.valueOf(5.0*-4.9),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void multiplicacionNegativoPositivo_Decimal() {
		separador.agregar("-5.2x4.9");
		assertEquals(Double.valueOf(-5.2*4.9),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void multiplicacionNegativoNegativo_Decimal() {
		separador.agregar("-5.0x-4.9");
		assertEquals(Double.valueOf(-5.0*-4.9),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}

}
