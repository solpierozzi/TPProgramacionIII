package CalculadoraTest;

import java.util.ArrayList;

public class SeparadorDeNumeros {
	private ArrayList<Character> operandos;
	private ArrayList<Double> numeros;
	
	public SeparadorDeNumeros(){
		operandos=new ArrayList<Character>();
		numeros=new ArrayList<Double>();
	}
	// Almacena los operandos en la lista operandos y los numeros en la lista numeros
		public void agregar(String s) {
			operandos.clear();
			numeros.clear();
			int ultimoOperando = 0, operandoAnterior = 0;
			for (int i = 1; i < s.length(); i++) {
				if (esOperando(s.charAt(i))) {
					if (esOperando(s.charAt(i - 1))) {
						if (numeros.isEmpty()) {
							ultimoOperando = i;
							operandos.add(s.charAt(i));
						} 
						else
							operandoAnterior++;
					} 
					else {
						operandoAnterior = ultimoOperando;
						ultimoOperando = i;
						operandos.add(s.charAt(i));
						if (numeros.isEmpty())
							numeros.add(Double.parseDouble(s.substring(operandoAnterior, ultimoOperando)));
						else
							numeros.add(Double.parseDouble(s.substring(operandoAnterior + 1, ultimoOperando)));
					}
				}
			}
			if (numeros.isEmpty())
				numeros.add(Double.parseDouble(s.substring(ultimoOperando,s.length())));
			else
				numeros.add(Double.parseDouble(s.substring(ultimoOperando + 1,s.length())));	
		}
	private boolean esOperando(char c){
		return c=='+' || c=='-' || c=='x' || c=='/';
	}
	public ArrayList<Double> getNumeros(){
		return numeros;
	}
	public ArrayList<Character> getOperandos(){
		return operandos;
	}
}
