package CalculadoraTest;

import static org.junit.Assert.*;
import logic.Calculadora;
import org.junit.Before;
import org.junit.Test;

public class RestaTest {
	Calculadora calculadora;
	SeparadorDeNumeros separador;
	
	@Before public void inicializar(){
		calculadora=new Calculadora();
		separador=new SeparadorDeNumeros();
	}
	
	@Test
	public void restaNegativoNegativo(){
		separador.agregar("--2.0--3.0");
		assertEquals(Double.valueOf(-(-2.0)-(-3.0)),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	@Test
	public void restaPositivoPositivo(){
		separador.agregar("3.0-2.0");
		assertEquals(Double.valueOf(3.0-2.0),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	@Test
	public void restaPositivoNegativo(){
		separador.agregar("2.0--3.0");
		assertEquals(Double.valueOf(2.0-(-3.0)),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	@Test
	public void restaNegativoPositivo(){
		separador.agregar("-2.0-3.0");
		assertEquals(Double.valueOf(-2.0-3.0),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void restaNegativoNegativo_Decimal(){
		separador.agregar("--2.2--3.2");
		assertEquals(Double.valueOf(-(-2.2)-(-3.2)),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	@Test
	public void restaPositivoPositivo_Decimal(){
		separador.agregar("3.3-2.2");
		assertEquals(Double.valueOf(3.3-2.2),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	@Test
	public void restaPositivoNegativo_Decimal(){
		separador.agregar("2.4--3.2");
		assertEquals(Double.valueOf(2.4-(-3.2)),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	@Test
	public void restaNegativoPositivo_Decimal(){
		separador.agregar("-2.2-3.2");
		assertEquals(Double.valueOf(-2.2-3.2),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void menosPorMenos_Decimal() {
		separador.agregar("--4.4");
		assertEquals(Double.valueOf(-(-4.4)), calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	
	
	
	@Test
	public void menosPorMenos() {
		separador.agregar("--4.0");
		assertEquals(Double.valueOf(-(-4.0)), calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void variasRestasTest() {
		separador.agregar("-2.0-5.0-7.0");
		assertEquals(Double.valueOf(-2.0-5.0-7.0),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	@Test
	public void variasRestasTest_Decimal() {
		separador.agregar("-2.3-5.0-7.2");
		assertEquals(Double.valueOf(-2.3-5.0-7.2),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
}
