package CalculadoraTest;

import static org.junit.Assert.*;
import logic.Calculadora;

import org.junit.Before;
import org.junit.Test;

public class CombinadosTest {
	Calculadora calculadora;
	SeparadorDeNumeros separador;
	@Before public void inicializar(){
		calculadora=new Calculadora();
		separador=new SeparadorDeNumeros();
	}
	
	@Test
	public void calculoCombinadoTest() {
		separador.agregar("-4+3x2");
		assertEquals(Double.valueOf(-4+3*2),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void calculoCombinado2Test() {
		separador.agregar("3.0x-5.0+10.0/2.0+1.0/2.0");
		assertEquals(Double.valueOf(3.0*-5.0+10.0/2.0+1.0/2.0), calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	}
	
	@Test
	public void mismoNumero(){
		separador.agregar("-2");
		assertEquals(Double.valueOf(-2.0),calculadora.operar(separador.getOperandos(),separador.getNumeros()));
	
	}
}
